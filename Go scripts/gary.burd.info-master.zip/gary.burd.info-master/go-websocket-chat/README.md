This directory contains the example code for the article at
http://gary.burd.info/go-websocket-chat. Read the article for a description of
the code and instructions for running the example.
